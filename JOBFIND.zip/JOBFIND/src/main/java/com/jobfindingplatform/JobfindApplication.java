package com.jobfindingplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan(basePackages = "com.jobfindigplatform.Entity")
@ComponentScan(basePackages = "com.jobfindingplatform")
public class JobfindApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobfindApplication.class, args);
	}

}
