package com.jobfindingplatform;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbtest {
  public static void main(String[] args) throws Exception {
    String url = "jdbc:mysql://127.0.0.1:3306/job_find?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    String user = "root";       // or root 
    String pass = "devraj9528";// your password 

    try (Connection con = DriverManager.getConnection(url, user, pass)) {
      System.out.println("✅ Connected to MySQL!");
    }
  }
}
