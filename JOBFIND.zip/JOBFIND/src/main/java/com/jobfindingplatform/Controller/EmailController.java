package com.jobfindingplatform.Controller;


import java.util.Map;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobfindingplatform.DTO.EmailRequestDTO;
import com.jobfindingplatform.Service.EmailService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class EmailController {

	
	@Autowired
	private EmailService emailService;
	
	@PostMapping("/send")
	public ResponseEntity<String>sendEmail(@RequestBody EmailRequestDTO dto ){
		emailService.sendEmail(dto,null);
		return ResponseEntity.ok("Email sent successfully");
	}
	@PostMapping("/send-invoice")
		 public String sendInvoice(Map<String, String> payload) {
		        String to = payload.get("to");
		        String subject = payload.get("subject");
		        String body = payload.get("body");
		        String pdfBase64 = payload.get("pdfBytes");

		        byte[] pdfBytes = Base64.getDecoder().decode(pdfBase64);

		        EmailRequestDTO request = new EmailRequestDTO();
		        emailService.sendEmail(request, pdfBytes);

		        return "Invoice Email Sent Successfully";
		 }
}
