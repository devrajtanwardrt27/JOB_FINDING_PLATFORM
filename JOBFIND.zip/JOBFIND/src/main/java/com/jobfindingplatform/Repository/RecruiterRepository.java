package com.jobfindingplatform.Repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jobfindingplatform.Entity.Recruiter;

@Repository
public interface RecruiterRepository extends JpaRepository<Recruiter, Long> {

    // Custom query method to find a Recruiter by their email address
    Optional<Recruiter> findByRecruiterEmail(String recruiterEmail);
}

