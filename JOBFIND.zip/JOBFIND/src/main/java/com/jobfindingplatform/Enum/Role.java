package com.jobfindingplatform.Enum;

public enum Role{
	JOBSEKKER,RECRUITER,ADMIN
}