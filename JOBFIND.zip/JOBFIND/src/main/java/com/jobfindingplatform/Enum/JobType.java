package com.jobfindingplatform.Enum;

public enum JobType {
   INTERNSHIP ,EXPERIENCE,FULLTIME,PARTTIME,CONTRACTUAL,FREELANCING
   
}