package com.jobfindingplatform.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobfindingplatform.DTO.RecruiterDTO;
import com.jobfindingplatform.Entity.Recruiter;
import com.jobfindingplatform.Repository.RecruiterRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor // For constructor injection of dependencies
public class RecruiterService {

    @Autowired
    private RecruiterRepository recruiterRepo;


    public RecruiterDTO createRecruiterProfile(RecruiterDTO dto) {
        // 1. Map DTO to Entity
        Recruiter recruiter =  new Recruiter();
        recruiter.setRecruiterName(dto.getRecruiterName());
        recruiter.setRecruiterEmail(dto.getRecruiterEmail());
        recruiter.setCompanyName(dto.getCompanyName());
        recruiter.setPhone(dto.getPhone());
        recruiter.setDesignation(dto.getDesignation());
        
      
        Recruiter saved = recruiterRepo.save(recruiter);
        
      
        return mapToDTO(saved);
    }

    public Optional<RecruiterDTO> getRecruiterByEmail(String email) {
        // Find by email and map the result to DTO if present
        return recruiterRepo.findByRecruiterEmail(email).map(this::mapToDTO);
    }

    public Optional<RecruiterDTO> getRecruiterById(Long id) {
        // Find by ID and map the result to DTO if present
        return recruiterRepo.findById(id).map(this::mapToDTO);
    }

 
    private RecruiterDTO mapToDTO(Recruiter req) {
        // Mapping fields using setters to match the structure implied by the image
        RecruiterDTO dto = new RecruiterDTO();
        dto.setRecruiterName(req.getRecruiterName());
        dto.setPhone(req.getPhone());
        dto.setRecruiterEmail(req.getRecruiterEmail());
        dto.setCompanyName(req.getCompanyName());
        dto.setDesignation(req.getDesignation());
        
        return dto;
    }
}
