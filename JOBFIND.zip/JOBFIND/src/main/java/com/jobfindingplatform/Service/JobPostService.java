package com.jobfindingplatform.Service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.jobfindingplatform.DTO.JobPostDTO;
import com.jobfindingplatform.Entity.JobPost;
import com.jobfindingplatform.Repository.JobPostRepository;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobPostService {

    private  JobPostRepository jobPostRepo;

    public String createJobPost(JobPostDTO dto) {
        JobPost job = new JobPost();

        job.setCompanyName(dto.getCompanyName());
        job.setJobType(dto.getJobType());
        job.setJobCategory(dto.getJobCategory());
        job.setJobDescrption(dto.getJobDescrption());
        job.setJobLocation(dto.getJobLocation());
        job.setJobTitle(dto.getJobTitle());
        job.setPostedBy(dto.getPostedBy());
        job.setRemote(dto.getRemote());
        job.setPostedAt(LocalDateTime.now()); // Set postedAt here, as it was missing in the original image but necessary

        jobPostRepo.save(job);

        return "Job got posted";
    }


    public List<JobPostDTO> getAllJobs() {
        return jobPostRepo.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByCompanyName(String companyName) {
        return jobPostRepo.findByCompanyName(companyName).stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    private JobPostDTO mapToDTO(JobPost jobPost) {
        JobPostDTO dto = new JobPostDTO();
        dto.setCompanyName(jobPost.getCompanyName());
        dto.setJobCategory(jobPost.getJobCategory());
        dto.setJobDescrption(jobPost.getJobDescrption());
        dto.setJobType(jobPost.getJobType());
        dto.setJobTitle(jobPost.getJobTitle());
        dto.setPostedBy(jobPost.getPostedBy());
        dto.setJobLocation(jobPost.getJobLocation());
        dto.setPostedAt(jobPost.getPostedAt());
        dto.setRemote(jobPost.getRemote());
        return dto;
    }
}



