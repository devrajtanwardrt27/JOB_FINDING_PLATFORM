package com.jobfindingplatform.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobfindingplatform.DTO.CoursesDTO;
import com.jobfindingplatform.Entity.Course;
import com.jobfindingplatform.Repository.CoursesRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CoursesService {

    @Autowired
    private CoursesRepository courseRepo;

    public CoursesDTO addCourse(CoursesDTO dto) {
        Course course = new Course();
        course.setCourseTitle(dto.getCourseTitle());
        course.setCourseDescripton(dto.getCourseDescripton());
        course.setCourseCategory(dto.getCourseCategory());
        course.setAdminId(dto.getAdminId());
        
        course.setCreatedAt(LocalDateTime.now());
        course.setActive(true);

        courseRepo.save(course);

        dto.setId(course.getId());
        dto.setAdminId(course.getAdminId()); 
        dto.setActive(course.isActive());
        
        return dto;
    }

    public List<CoursesDTO> getAllActiveCourses() {
        return courseRepo.findByActiveTrue().stream().map(c -> {
            CoursesDTO dto = new CoursesDTO();
            dto.setId(c.getId());
            dto.setCourseTitle(c.getCourseTitle());
            dto.setCourseDescripton(c.getCourseDescripton());
            dto.setCourseCategory(c.getCourseCategory());
            dto.setAdminId(c.getAdminId());
            dto.setActive(c.isActive());
            return dto;
        }).collect(Collectors.toList());
    }

    public void deActiveCourse(Long id) {
        Course course = courseRepo.findById(id).orElseThrow(() -> new RuntimeException("Course not found with id: " + id));
        course.setActive(false);
        courseRepo.save(course);
    }
   }
