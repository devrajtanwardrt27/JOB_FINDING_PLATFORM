package com.jobfindingplatform.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

import com.jobfindingplatform.Enum.JobType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobPostDTO {

	  private Long id;
	    private String jobTitle;
	    private String jobType;
	    private String jobLocation;
	    private Long remote;
	    private Long companyName;
	    private Long jobCategory;
	    private Long jobDescrption;
	    private Long postedBy;
	    private LocalDateTime postedAt;
	    
	    private boolean active =true;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getJobTitle() {
			return jobTitle;
		}

		public void setJobTitle(String jobTitle) {
			this.jobTitle = jobTitle;
		}

		public String getJobType() {
			return jobType;
		}

		public void setJobType(String jobType) {
			this.jobType = jobType;
		}

		public String getJobLocation() {
			return jobLocation;
		}

		public void setJobLocation(String jobLocation) {
			this.jobLocation = jobLocation;
		}

		public Long getRemote() {
			return remote;
		}

		public void setRemote(Long remote) {
			this.remote = remote;
		}

		public Long getCompanyName() {
			return companyName;
		}

		public void setCompanyName(Long companyName) {
			this.companyName = companyName;
		}

		public Long getJobCategory() {
			return jobCategory;
		}

		public void setJobCategory(Long jobCategory) {
			this.jobCategory = jobCategory;
		}

		public Long getJobDescrption() {
			return jobDescrption;
		}

		public void setJobDescrption(Long jobDescrption) {
			this.jobDescrption = jobDescrption;
		}

		public Long getPostedBy() {
			return postedBy;
		}

		public void setPostedBy(Long postedBy) {
			this.postedBy = postedBy;
		}

		public LocalDateTime getPostedAt() {
			return postedAt;
		}

		public void setPostedAt(LocalDateTime postedAt) {
			this.postedAt = postedAt;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}
	    
    
    

}
    

