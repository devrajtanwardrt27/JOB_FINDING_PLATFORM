package com.jobfindingplatform.Enum;

public enum Duration {
     MONTHLY,QUATERLY,YEARLY
}
