package com.jobfindingplatform.Entity;

import java.time.LocalDateTime;

import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name ="chatSupport")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatSupport {
      
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long Id;
	private String senderId;
	private String receiverId;
	private LocalDateTime timeStamp;
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public String getSenderId() {
		return senderId;
	}
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
	public String getReceiverId() {
		return receiverId;
	}
	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	
	
	
	
}
