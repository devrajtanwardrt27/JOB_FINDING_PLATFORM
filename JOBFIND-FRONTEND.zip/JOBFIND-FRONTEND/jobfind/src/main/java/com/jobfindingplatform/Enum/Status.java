package com.jobfindingplatform.Enum;

public enum Status {
APPLIED ,SHORTLISTED ,REJECTED 
}
