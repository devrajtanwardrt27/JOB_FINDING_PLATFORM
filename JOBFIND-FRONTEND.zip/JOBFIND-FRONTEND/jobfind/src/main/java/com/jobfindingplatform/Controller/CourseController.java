package com.jobfindingplatform.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobfindingplatform.DTO.CoursesDTO;
import com.jobfindingplatform.Service.CoursesService;

import lombok.RequiredArgsConstructor;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseController {
	
	@Autowired
	private CoursesService courseService;

	@PostMapping("/add/{adminId}")
	public ResponseEntity<CoursesDTO> addCourse(@RequestBody CoursesDTO dto) {
		return ResponseEntity.ok(courseService.addCourse(dto));
	}
	
	@GetMapping
	public ResponseEntity<List<CoursesDTO>> getCourse() {
		return ResponseEntity.ok(courseService.getAllActiveCourses());
	}
}
