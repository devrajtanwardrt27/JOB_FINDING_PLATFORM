package com.jobfindingplatform.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobfindingplatform.DTO.JobSeekerDTO;
import com.jobfindingplatform.Entity.JobSeeker;
import com.jobfindingplatform.Repository.JobSeekerRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JobSeekerService {
	
	@Autowired
	private JobSeekerRepository jobSeekerRepo;
	
	
	
	public JobSeekerDTO createJobseekerProfile(JobSeekerDTO dto) {
		
		JobSeeker jobseeker = new JobSeeker();
		
		jobseeker.setFullName(dto.getFullName());
		jobseeker.setEmail(dto.getEmail());
		jobseeker.setPhone(dto.getPhone());
		jobseeker.setCollegeName(dto.getCollegeName());
		jobseeker.setUniversityName(dto.getUniversityName());
		jobseeker.setPassingYear(dto.getPassingYear());
		jobseeker.setDegree(dto.getDegree());
		jobseeker.setResumeURL(dto.getResumeURL());
		jobseeker.setActive(dto.isActive());
		
		jobSeekerRepo.save(jobseeker);
		return dto;
		
	}
	
	
	public Optional<JobSeekerDTO>getJobSeekerByEmail(String email){
		
		return jobSeekerRepo.findByJobSeekerEmail(email).map(jobSeek ->{
			                                     
			                                    JobSeekerDTO dto = new JobSeekerDTO();
			                                    dto.setFullName(jobSeek.getFullName());
			                                    dto.setEmail(jobSeek.getEmail());
			                                    dto.setPhone(jobSeek.getPhone());
			                                    dto.setCollegeName(jobSeek.getCollegeName());
			                                    dto.setUniversityName(jobSeek.getUniversityName());
			                                    dto.setPassingYear(jobSeek.getPassingYear());
			                                    dto.setDegree(jobSeek.getDegree());
			                                    dto.setResumeURL(jobSeek.getResumeURL());
			                                    return dto;
			                                    		
		                                            });
	}
	
	public Optional<JobSeekerDTO>getJobSeekerById(Long id){
		
		return jobSeekerRepo.findById(id).map(jobSeeks->{
			
			JobSeekerDTO dto = new JobSeekerDTO();
            dto.setFullName(jobSeeks.getFullName());
            dto.setEmail(jobSeeks.getEmail());
            dto.setPhone(jobSeeks.getPhone());
            dto.setCollegeName(jobSeeks.getCollegeName());
            dto.setUniversityName(jobSeeks.getUniversityName());
            dto.setPassingYear(jobSeeks.getPassingYear());
            dto.setDegree(jobSeeks.getDegree());
            dto.setResumeURL(jobSeeks.getResumeURL());
            return dto;
            		 });
	}

}