package com.jobfindingplatform.Service;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jobfindingplatform.DTO.AuthResponseDTO;
import com.jobfindingplatform.DTO.LoginRequestDTO;
import com.jobfindingplatform.DTO.UserDTO;
import com.jobfindingplatform.Entity.User;
import com.jobfindingplatform.Security.JWTUtil;
import com.jobfindingplatform.Repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthService {
@Autowired
private UserRepository userRepository;
@Autowired
private JWTUtil jwtUtil;
@Autowired
private PasswordEncoder passwordEncoder;
@Autowired
private AuthenticationManager authenticationManger;

public AuthResponseDTO register(UserDTO dto) {
        User user = new User();
        user.setUsername(dto.getUserName());
        user.setEmail(dto.getUserMail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole(dto.getRole());
        userRepository.save(user);

       String token= jwtUtil.generateToken(user);
       return new AuthResponseDTO(token, "user got registered");
    }
public String login(LoginRequestDTO dto) {

    User user = userRepository.findbyUserEmail(dto.getUserMail())
        .orElseThrow(() -> new RuntimeException("User not found"));

    if(!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {

        throw new RuntimeException("Invalid credentials");
    }
    return jwtUtil.generateToken(user);
}
}

