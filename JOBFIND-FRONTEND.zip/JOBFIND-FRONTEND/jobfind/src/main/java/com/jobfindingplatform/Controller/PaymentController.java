package com.jobfindingplatform.Controller;


import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.jobfindingplatform.Repository.SubscriptionPlanRepository;
import com.jobfindingplatform.Service.InvoiceService;
import com.jobfindingplatform.Service.PaymentService;
import com.jobfindingplatform.DTO.PaymentRequestDTO;
import com.jobfindingplatform.DTO.PaymentResponseDTO;
import com.jobfindingplatform.Entity.SubscriptionPlan;
import com.jobfindingplatform.Entity.Payment;
import com.jobfindingplatform.Repository.PaymentRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("payment")
@RequiredArgsConstructor
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private SubscriptionPlanRepository subPlanRepo;

    @Autowired
    private PaymentRepository paymentRepo;
    
    @Autowired
    private InvoiceService invoiceService;

    @PostMapping("/process")
    public ResponseEntity<PaymentResponseDTO> processPayment(@RequestBody PaymentRequestDTO dto) {
        return ResponseEntity.ok(paymentService.processPayment(dto));
    }

    @GetMapping("/plans")
    public ResponseEntity<List<SubscriptionPlan>> getPlans() {
        return ResponseEntity.ok(subPlanRepo.findAll());
    }

    @PostMapping("/plans")
    public ResponseEntity<SubscriptionPlan> createPlans(@RequestBody SubscriptionPlan plan) {
        return ResponseEntity.ok(subPlanRepo.save(plan));
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<Payment>> history(@PathVariable Long userId) {
        return ResponseEntity.ok(paymentRepo.findByUserId(userId));
    }
    @GetMapping("/invoice/{paymentId}")
    public ResponseEntity<byte[]> downloadInvoice(@PathVariable long paymentId) {
        
        Payment pay = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));

        byte[] pdfBytes = invoiceService.generateInvoice(pay);

        return ResponseEntity.ok()
                .header("Content-Disposition", "Attachment; filename=Invoice-" + pay.getTransactionId() + ".pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
