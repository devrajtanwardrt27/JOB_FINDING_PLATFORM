package com.jobfindingplatform.Repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jobfindingplatform.Entity.JobSeeker;

@Repository
public interface JobSeekerRepository extends JpaRepository<JobSeeker, Long> {

    Optional<JobSeeker> findByJobSeekerEmail(String email);
    Optional<JobSeeker> findByJobSeekerId(Long id);
}
