package com.jobfindingplatform.Enum;

public enum PaymentStatus {
       SUCCESS,FAILED,PENDING
}
