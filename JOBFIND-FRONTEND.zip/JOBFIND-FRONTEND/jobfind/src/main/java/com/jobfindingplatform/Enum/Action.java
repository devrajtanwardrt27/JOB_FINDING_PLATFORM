package com.jobfindingplatform.Enum;

public enum Action {
   BLOCK ,UNBLOCK
}
