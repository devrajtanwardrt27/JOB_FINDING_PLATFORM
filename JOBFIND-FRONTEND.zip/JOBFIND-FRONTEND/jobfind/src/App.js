import React, { useState, useEffect, useMemo, useCallback } from 'react';

// --- MOCK DATA ---
const mockJobs = [
    { id: 1, title: "Senior Frontend Engineer", company: "InnovateTech Solutions", location: "Remote", type: "Full-Time", salary: "$140k - $180k", posted: "2 days ago", description: "Design and implement complex user interfaces using React, TypeScript, and modern state management. You will lead UI architecture decisions and mentor junior developers. 5+ years of experience required." },
    { id: 2, title: "Cloud Data Engineer (GCP/AWS)", company: "Global Datasets Inc.", location: "New York, NY", type: "Full-Time", salary: "$150k - $195k", posted: "5 hours ago", description: "Develop and maintain scalable data pipelines in a cloud environment (GCP preferred). Expertise in Python, SQL, and distributed systems is essential. Certifications are a plus." },
    { id: 3, title: "Product Manager (E-commerce)", company: "Market Movers", location: "Los Angeles, CA", type: "Contract", salary: "$70/hr - $90/hr", posted: "1 week ago", description: "Own the product roadmap for our flagship e-commerce platform. Must have a strong background in user experience, A/B testing, and agile methodologies." },
    { id: 4, title: "Entry-Level Graphic Designer", company: "Creative Spark Studio", location: "Remote, US only", type: "Internship", salary: "$20/hr", posted: "3 days ago", description: "Assist the senior design team with daily production tasks, branding updates, and social media content. Portfolio required. Must be proficient in Adobe Creative Suite." },
];

const SearchIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
);

const BriefcaseIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
);

const MapPinIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
);

const UserIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);

const DollarSignIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
);


// --- COMPONENTS ---

/**
 * Job Card component for the list view.
 */
const JobCard = ({ job, onViewDetails }) => (
    <div
        className="bg-white p-6 border border-gray-100 rounded-xl shadow-lg hover:shadow-xl transition duration-300 cursor-pointer flex flex-col space-y-3"
        onClick={() => onViewDetails(job)}
    >
        <div className="flex items-start justify-between">
            <div>
                <h3 className="text-xl font-bold text-gray-800 hover:text-indigo-600 transition-colors">{job.title}</h3>
                <p className="text-sm text-indigo-600 font-medium mt-1">{job.company}</p>
            </div>
            <span className="text-xs text-gray-500 font-semibold bg-indigo-50 px-3 py-1 rounded-full">{job.type}</span>
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-gray-600">
            <div className="flex items-center">
                <MapPinIcon className="w-4 h-4 mr-1 text-gray-400" />
                {job.location}
            </div>
            <div className="flex items-center">
                <DollarSignIcon className="w-4 h-4 mr-1 text-gray-400" />
                {job.salary}
            </div>
        </div>
        <p className="text-sm text-gray-500 line-clamp-2 mt-2">{job.description.substring(0, 100)}...</p>

        <div className="pt-3 border-t border-gray-100 flex justify-between items-center">
            <span className="text-xs text-gray-500">Posted {job.posted}</span>
            <button className="text-sm font-semibold text-indigo-600 hover:text-indigo-800 transition-colors">
                View Job &rarr;
            </button>
        </div>
    </div>
);

/**
 * Main Job Listing and Search View.
 */
const HomeView = ({ jobs, onViewDetails }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [locationFilter, setLocationFilter] = useState('');

    const filteredJobs = useMemo(() => {
        return jobs.filter(job => {
            const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                  job.company.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesLocation = locationFilter === '' || job.location.toLowerCase().includes(locationFilter.toLowerCase());
            return matchesSearch && matchesLocation;
        });
    }, [jobs, searchTerm, locationFilter]);

    return (
        <div className="p-4 sm:p-8">
            {/* Search Bar and Filters */}
            <div className="bg-white p-6 rounded-xl shadow-xl mb-8">
                <h2 className="text-2xl font-extrabold text-gray-900 mb-4">Find Your Dream Job</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="relative">
                        <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Job Title, Keywords..."
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="relative">
                        <MapPinIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Location (e.g., Remote, NY)"
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition"
                            value={locationFilter}
                            onChange={(e) => setLocationFilter(e.target.value)}
                        />
                    </div>
                    <button
                        className="w-full py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition duration-200"
                        onClick={() => { /* In a real app, this might trigger a server fetch */ }}
                    >
                        Search Jobs
                    </button>
                </div>
            </div>

            {/* Job Listings */}
            <h2 className="text-xl font-bold text-gray-800 mb-6">Showing {filteredJobs.length} Results</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredJobs.length > 0 ? (
                    filteredJobs.map(job => (
                        <JobCard key={job.id} job={job} onViewDetails={onViewDetails} />
                    ))
                ) : (
                    <p className="text-gray-500 col-span-full text-center p-10 bg-white rounded-xl shadow-md">
                        No jobs found matching your criteria. Try adjusting your search.
                    </p>
                )}
            </div>
        </div>
    );
};

/**
 * Job Details View component.
 */
const JobDetailsView = ({ job, onBackToList }) => {
    if (!job) {
        // Should not happen, but a safeguard
        return <div className="p-8 text-center text-red-500">Job not found.</div>;
    }

    return (
        <div className="max-w-4xl mx-auto p-4 sm:p-8">
            <button
                onClick={onBackToList}
                className="flex items-center text-indigo-600 hover:text-indigo-800 font-medium mb-6 transition-colors"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                Back to Job Listings
            </button>

            <div className="bg-white p-6 sm:p-10 rounded-xl shadow-xl">
                <h1 className="text-3xl font-extrabold text-gray-900 mb-2">{job.title}</h1>
                <p className="text-xl text-indigo-600 font-semibold mb-6">{job.company}</p>

                {/* Quick Facts */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex flex-col items-center">
                        <BriefcaseIcon className="w-6 h-6 text-indigo-500 mb-1" />
                        <span className="text-sm font-medium text-gray-600">{job.type}</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <MapPinIcon className="w-6 h-6 text-indigo-500 mb-1" />
                        <span className="text-sm font-medium text-gray-600">{job.location}</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <DollarSignIcon className="w-6 h-6 text-indigo-500 mb-1" />
                        <span className="text-sm font-medium text-gray-600">{job.salary}</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2v20M5 12h14"/></svg>
                        <span className="text-sm font-medium text-gray-600">{job.posted}</span>
                    </div>
                </div>

                {/* Description */}
                <h2 className="text-2xl font-bold text-gray-800 mb-4 border-b pb-2">Job Description</h2>
                <div className="text-gray-700 space-y-4">
                    <p>{job.description}</p>
                    <p>This role offers a challenging opportunity to work with cutting-edge technology and a collaborative team. We value innovation and continuous learning. Full benefits package included.</p>

                    <h3 className="text-xl font-semibold mt-6">Responsibilities include:</h3>
                    <ul className="list-disc pl-6 space-y-2">
                        <li>Collaborating with cross-functional teams to define, design, and ship new features.</li>
                        <li>Ensuring the performance, quality, and responsiveness of the application.</li>
                        <li>Maintaining code quality, organization, and automation.</li>
                    </ul>

                    <h3 className="text-xl font-semibold mt-6">Minimum Qualifications:</h3>
                    <ul className="list-disc pl-6 space-y-2">
                        <li>{job.description.includes('5+ years') ? '5+ years of relevant experience.' : '2+ years of relevant experience.'}</li>
                        <li>Demonstrated proficiency in the required technology stack.</li>
                    </ul>
                </div>

                {/* Apply Button */}
                <div className="mt-8 pt-6 border-t border-gray-200">
                    <button className="w-full py-4 bg-green-500 text-white text-lg font-bold rounded-lg shadow-lg hover:bg-green-600 transition duration-300 transform hover:scale-[1.01]">
                        Apply Now
                    </button>
                    <p className="text-xs text-gray-500 text-center mt-2">External application link will open.</p>
                </div>
            </div>
        </div>
    );
};

/**
 * Login/Signup View component.
 */
const AuthView = ({ onAuthSuccess, mode, setMode }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        setError('');
        if (!email || !password) {
            setError('Please fill out all fields.');
            return;
        }

        // Simulate API call
        console.log(`${mode} attempt with: ${email}`);
        setTimeout(() => {
            if (email === 'user@example.com' && password === 'password') {
                onAuthSuccess();
            } else if (mode === 'login') {
                setError('Invalid credentials. Use user@example.com / password.');
            } else {
                // Simulated signup success
                onAuthSuccess();
            }
        }, 800);
    };

    return (
        <div className="flex justify-center items-center p-4 min-h-[80vh]">
            <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl border border-gray-100">
                <h2 className="text-3xl font-bold text-gray-900 text-center mb-6">
                    {mode === 'login' ? 'Welcome Back' : 'Create an Account'}
                </h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative text-sm" role="alert">
                            {error}
                        </div>
                    )}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full py-3 mt-4 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition duration-200 transform hover:scale-[1.005]"
                    >
                        {mode === 'login' ? 'Login' : 'Sign Up'}
                    </button>
                </form>

                <div className="mt-6 text-center">
                    <button
                        onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
                        className="text-sm text-indigo-600 hover:text-indigo-800 font-medium transition-colors"
                    >
                        {mode === 'login' ? "Don't have an account? Sign Up" : "Already have an account? Login"}
                    </button>
                </div>
            </div>
        </div>
    );
};


// --- MAIN APP COMPONENT ---

const App = () => {
    // State for navigation: 'home', 'details', 'login'
    const [currentPage, setCurrentPage] = useState('home');
    const [selectedJob, setSelectedJob] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [authMode, setAuthMode] = useState('login'); // 'login' or 'signup'

    const handleViewDetails = (job) => {
        setSelectedJob(job);
        setCurrentPage('details');
    };

    const handleBackToList = () => {
        setSelectedJob(null);
        setCurrentPage('home');
    };

    const handleAuthSuccess = () => {
        setIsLoggedIn(true);
        setCurrentPage('home');
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setCurrentPage('home');
    };

    // Render the current page view
    const renderContent = () => {
        switch (currentPage) {
            case 'details':
                return <JobDetailsView job={selectedJob} onBackToList={handleBackToList} />;
            case 'login':
                return <AuthView onAuthSuccess={handleAuthSuccess} mode={authMode} setMode={setAuthMode} />;
            case 'home':
            default:
                return <HomeView jobs={mockJobs} onViewDetails={handleViewDetails} />;
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 font-sans">
            {/* Navigation Header */}
            <header className="bg-white shadow-md sticky top-0 z-10">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-16">
                        {/* Logo/Brand */}
                        <div className="flex-shrink-0">
                            <span className="text-2xl font-extrabold text-indigo-600 cursor-pointer" onClick={() => setCurrentPage('home')}>
                                JobFinder<span className="text-gray-900">Pro</span>
                            </span>
                        </div>

                        {/* Navigation Links and Auth */}
                        <nav className="flex items-center space-x-4">
                            <button
                                onClick={() => setCurrentPage('home')}
                                className={`text-gray-600 hover:text-indigo-600 font-medium transition-colors ${currentPage === 'home' ? 'text-indigo-600 border-b-2 border-indigo-600' : ''}`}
                            >
                                Jobs
                            </button>

                            {isLoggedIn ? (
                                <div className="flex items-center space-x-3">
                                    <UserIcon className="w-5 h-5 text-gray-500" />
                                    <button
                                        onClick={handleLogout}
                                        className="px-3 py-1 text-sm font-medium bg-red-100 text-red-600 border border-red-300 rounded-full hover:bg-red-200 transition"
                                    >
                                        Logout
                                    </button>
                                </div>
                            ) : (
                                <button
                                    onClick={() => { setCurrentPage('login'); setAuthMode('login'); }}
                                    className="px-4 py-2 text-sm font-semibold bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition duration-200"
                                >
                                    Login / Register
                                </button>
                            )}
                        </nav>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto pb-12">
                {renderContent()}
            </main>

            {/* Footer */}
            <footer className="bg-gray-800 text-white p-4 sm:p-6 mt-8">
                <div className="max-w-7xl mx-auto text-center">
                    <p className="text-sm">
                        &copy; {new Date().getFullYear()} JobFinderPro. All rights reserved.
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                        Frontend implementation using React and Tailwind CSS.
                    </p>
                </div>
            </footer>
        </div>
    );
};

export default App;
